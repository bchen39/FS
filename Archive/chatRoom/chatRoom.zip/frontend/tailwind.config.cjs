module.exports = {
    content: [
        "./src/*.jsx",
        "./src/Route/*.jsx"
    ],
    theme: {
        extend: {}
    },
    plugins: [],
}